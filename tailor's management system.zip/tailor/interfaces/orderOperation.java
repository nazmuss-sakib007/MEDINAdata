package interfaces;
import classes.*;
public interface orderOperation
{

void placeOrder(order o2 );
//void showAllOrders();







}