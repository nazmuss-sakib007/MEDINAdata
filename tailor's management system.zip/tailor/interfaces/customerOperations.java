package interfaces;
import classes.*;
public interface customerOperations
{

void addCustomer(profile cc );
 void showAllCustomers();







}