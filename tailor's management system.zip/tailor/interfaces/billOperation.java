package interfaces;
import classes.*;
public interface billOperation 
{
      
  public void writeFile();
  public void readFile();
  
}
